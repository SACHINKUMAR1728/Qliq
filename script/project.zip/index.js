const { GoogleGenerativeAI } = require('@google/generative-ai');

// Initialize outside handler to reuse connection
const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);
const model = genAI.getGenerativeModel({
  model: 'gemini-1.5-flash',
});

const generationConfig = {
  temperature: 0.7,
  topP: 0.95,
  topK: 64,
  maxOutputTokens: 8192,
  responseMimeType: 'text/plain',
};

const extractTags = async (jsonArray, tagSet) => {
  const extractTagsWithRetry = async (item, retries = 2) => {
    const prompt = `Given the following NFT details:
    Name: ${item.name}
    Description: ${item.description}
    Identify which of the following tags are relevant: ${Array.from(tagSet).join(', ')}.
    List the relevant tags separated by commas. If no tags apply, return "None".`;

    try {
      const result = await model.generateContent({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig,
      });

      const response = await result.response;
      const text = response.text();

      // Process tags, handling "None" case
      return text.toLowerCase().trim() === 'none' 
        ? [] 
        : text.split(',').map(tag => tag.trim()).filter(tag => tag);
    } catch (error) {
      console.error(`Error processing item ${item.name}:`, error);
      
      if (retries > 0) {
        console.log(`Retrying item ${item.name}...`);
        return extractTagsWithRetry(item, retries - 1);
      }
      
      return [];
    }
  };

  // Extract tags for all items and flatten into a unique array
  const allTagResults = await Promise.all(jsonArray.map(extractTagsWithRetry));
  return [...new Set(allTagResults.flat())];
};

exports.handler = async (event) => {
  // Validate input
  if (!event.body) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: 'Missing request body' }),
    };
  }

  let parsedBody;
  try {
    parsedBody = JSON.parse(event.body);
  } catch (error) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: 'Invalid JSON body' }),
    };
  }

  // Validate required fields
  const { nftData, tagsToExtract } = parsedBody;
  
  if (!Array.isArray(nftData) || !Array.isArray(tagsToExtract)) {
    return {
      statusCode: 400,
      body: JSON.stringify({ 
        error: 'nftData and tagsToExtract must be arrays' 
      }),
    };
  }

  try {
    // Extract tags
    const results = await extractTags(
      nftData, 
      new Set(tagsToExtract)
    );

    // Successful response
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        tags: results
      }),
    };
  } catch (error) {
    console.error('Tag extraction error:', error);

    // Error response
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        error: 'Failed to extract tags',
        details: error.message 
      }),
    };
  }
};